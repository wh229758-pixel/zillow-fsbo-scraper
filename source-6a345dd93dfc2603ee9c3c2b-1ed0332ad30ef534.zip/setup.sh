#!/bin/bash

# setup.sh - One-click setup for the Zillow FSBO Scraper on Mac Mini
# Installs all dependencies, configures the virtual environment,
# installs Playwright Chromium, and sets up a daily cron job.

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

echo "=== Zillow FSBO Scraper — Setup ==="
echo "Working directory: $SCRIPT_DIR"
echo ""

# ---------------------------------------------------------------------------
# 1. Check for Python 3.9+
# ---------------------------------------------------------------------------
echo "[1/8] Checking for Python 3.9+..."

PYTHON_BIN=""
for candidate in python3 python3.13 python3.12 python3.11 python3.10 python3.9; do
    if command -v "$candidate" &>/dev/null; then
        version_output=$("$candidate" --version 2>&1)
        major=$(echo "$version_output" | sed -E 's/Python ([0-9]+)\..*/\1/')
        minor=$(echo "$version_output" | sed -E 's/Python [0-9]+\.([0-9]+)\..*/\1/')
        if [ "$major" -gt 3 ] || { [ "$major" -eq 3 ] && [ "$minor" -ge 9 ]; }; then
            PYTHON_BIN="$candidate"
            break
        fi
    fi
done

if [ -z "$PYTHON_BIN" ]; then
    echo "ERROR: Python 3.9 or higher is required but was not found." >&2
    echo "       Install it via Homebrew:  brew install python@3.11" >&2
    echo "       Or download from:         https://www.python.org/downloads/" >&2
    exit 1
fi

PYTHON_VERSION=$("$PYTHON_BIN" --version 2>&1)
echo "       Found: $PYTHON_VERSION ($PYTHON_BIN)"

# ---------------------------------------------------------------------------
# 2. Create Python virtual environment
# ---------------------------------------------------------------------------
echo ""
echo "[2/8] Creating virtual environment in $SCRIPT_DIR/venv..."

if [ -d "$SCRIPT_DIR/venv" ]; then
    echo "       Virtual environment already exists — skipping."
else
    "$PYTHON_BIN" -m venv "$SCRIPT_DIR/venv"
    echo "       Virtual environment created."
fi

VENV_PYTHON="$SCRIPT_DIR/venv/bin/python"
VENV_PIP="$SCRIPT_DIR/venv/bin/pip"

# ---------------------------------------------------------------------------
# 3. Install Python requirements
# ---------------------------------------------------------------------------
echo ""
echo "[3/8] Installing requirements from requirements.txt..."

# shellcheck source=/dev/null
source "$SCRIPT_DIR/venv/bin/activate"

if [ ! -f "$SCRIPT_DIR/requirements.txt" ]; then
    echo "WARNING: requirements.txt not found — skipping package installation." >&2
else
    "$VENV_PIP" install --upgrade pip --quiet
    "$VENV_PIP" install -r "$SCRIPT_DIR/requirements.txt"
    echo "       Requirements installed."
fi

# ---------------------------------------------------------------------------
# 4. Install Playwright Chromium browser
# ---------------------------------------------------------------------------
echo ""
echo "[4/8] Installing Playwright Chromium browser..."

if "$VENV_PYTHON" -m playwright install chromium; then
    echo "       Playwright Chromium installed."
else
    echo "WARNING: Playwright installation encountered an issue." >&2
    echo "         Run manually later: $VENV_PYTHON -m playwright install chromium" >&2
fi

# ---------------------------------------------------------------------------
# 5. Create .env file if it doesn't exist
# ---------------------------------------------------------------------------
echo ""
echo "[5/8] Checking .env file..."

ENV_FILE="$SCRIPT_DIR/.env"
if [ -f "$ENV_FILE" ]; then
    echo "       .env already exists — leaving it untouched."
else
    cat > "$ENV_FILE" <<'EOF'
# Anthropic API key — get yours at https://console.anthropic.com/account/keys
ANTHROPIC_API_KEY=your_key_here
EOF
    echo "       Created .env template at $ENV_FILE"
    echo ""
    echo "  ACTION REQUIRED: Open the .env file and replace 'your_key_here'"
    echo "  with your actual Anthropic API key."
    echo ""
fi

# ---------------------------------------------------------------------------
# 6. Ensure agents/__init__.py exists
# ---------------------------------------------------------------------------
echo ""
echo "[6/8] Ensuring agents package exists..."

AGENTS_DIR="$SCRIPT_DIR/agents"
mkdir -p "$AGENTS_DIR"

AGENTS_INIT="$AGENTS_DIR/__init__.py"
if [ ! -f "$AGENTS_INIT" ]; then
    echo '"""Zillow FSBO Scraper Agents."""' > "$AGENTS_INIT"
    echo "       Created $AGENTS_INIT"
else
    echo "       $AGENTS_INIT already exists."
fi

# ---------------------------------------------------------------------------
# 7. Check for google_credentials.json
# ---------------------------------------------------------------------------
echo ""
echo "[7/8] Checking for google_credentials.json..."

GOOGLE_CREDS="$SCRIPT_DIR/google_credentials.json"
if [ -f "$GOOGLE_CREDS" ]; then
    echo "       google_credentials.json found."
else
    echo ""
    echo "WARNING: google_credentials.json not found at $GOOGLE_CREDS" >&2
    echo "         To create one:" >&2
    echo "           1. Go to https://console.cloud.google.com/" >&2
    echo "           2. Create a project and enable the Google Sheets API." >&2
    echo "           3. Go to APIs & Services > Credentials." >&2
    echo "           4. Click 'Create Credentials' > 'Service account'." >&2
    echo "           5. Download the JSON key and rename it google_credentials.json." >&2
    echo "           6. Move it into this project folder." >&2
    echo "           7. Share your Google Sheet with the service account email." >&2
    echo "         See README.md Step 3 for detailed instructions." >&2
    echo ""
fi

# ---------------------------------------------------------------------------
# 8. Set up daily cron job
# ---------------------------------------------------------------------------
echo ""
echo "[8/8] Configuring cron job..."

CONFIG_FILE="$SCRIPT_DIR/config.json"
if [ ! -f "$CONFIG_FILE" ]; then
    echo "ERROR: config.json not found at $CONFIG_FILE" >&2
    exit 1
fi

SCHEDULE_HOUR=$("$VENV_PYTHON" -c "
import json, sys
with open('$CONFIG_FILE') as f:
    cfg = json.load(f)
hour = cfg.get('schedule_hour')
if hour is None:
    print('ERROR: schedule_hour missing from config.json', file=sys.stderr)
    sys.exit(1)
print(int(hour))
")

SCHEDULE_MINUTE=$("$VENV_PYTHON" -c "
import json, sys
with open('$CONFIG_FILE') as f:
    cfg = json.load(f)
minute = cfg.get('schedule_minute')
if minute is None:
    print('ERROR: schedule_minute missing from config.json', file=sys.stderr)
    sys.exit(1)
print(int(minute))
")

echo "       Schedule from config.json: ${SCHEDULE_HOUR}:$(printf '%02d' "$SCHEDULE_MINUTE") daily"

# cron command: cd to project dir, activate venv, run main.py, log output
CRON_CMD="cd \"$SCRIPT_DIR\" && source \"$SCRIPT_DIR/venv/bin/activate\" && \"$VENV_PYTHON\" \"$SCRIPT_DIR/main.py\" >> \"$SCRIPT_DIR/cron.log\" 2>&1"
CRON_ENTRY="${SCHEDULE_MINUTE} ${SCHEDULE_HOUR} * * * $CRON_CMD"
CRON_MARKER="$SCRIPT_DIR/main.py"

echo "       Updating crontab..."
(
    crontab -l 2>/dev/null | grep -v "$CRON_MARKER" || true
    echo "$CRON_ENTRY"
) | crontab -

echo "       Cron job installed."

# ---------------------------------------------------------------------------
# Success summary
# ---------------------------------------------------------------------------
echo ""
echo "======================================================"
echo " Setup complete!"
echo "======================================================"
echo ""
echo " Configured:"
echo "   Python venv   : $SCRIPT_DIR/venv"
echo "   Dependencies  : installed"
echo "   Playwright    : Chromium browser installed"
echo "   .env template : $ENV_FILE"
echo "   Cron schedule : daily at ${SCHEDULE_HOUR}:$(printf '%02d' "$SCHEDULE_MINUTE")"
echo "   Run log       : $SCRIPT_DIR/run.log"
echo "   Cron log      : $SCRIPT_DIR/cron.log"
echo ""

NEXT_RUN=$("$VENV_PYTHON" -c "
from datetime import datetime, timedelta
now = datetime.now()
run = now.replace(hour=$SCHEDULE_HOUR, minute=$SCHEDULE_MINUTE, second=0, microsecond=0)
if run <= now:
    run += timedelta(days=1)
print(run.strftime('%A %Y-%m-%d at %H:%M'))
")
echo " Next scheduled run: $NEXT_RUN"
echo ""

if [ ! -f "$GOOGLE_CREDS" ]; then
    echo " REMINDER: google_credentials.json is missing — see warnings above and README.md Step 3."
fi

if grep -q "your_key_here" "$ENV_FILE" 2>/dev/null; then
    echo " REMINDER: Edit .env and replace 'your_key_here' with your ANTHROPIC_API_KEY."
fi

echo ""
echo " To run manually right now:"
echo "   source venv/bin/activate && python main.py"
echo ""
echo " To test without writing to Google Sheets:"
echo "   source venv/bin/activate && python main.py --dry-run"
echo ""
