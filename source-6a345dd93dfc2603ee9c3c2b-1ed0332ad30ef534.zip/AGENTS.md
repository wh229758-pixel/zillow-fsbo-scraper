# AGENTS.md

## Project: Zillow FSBO Scraper

A 3-agent pipeline that automatically scrapes For Sale By Owner listings from Zillow, cleans the data with Claude AI, and appends results to Google Sheets. Designed to run unattended on a Mac Mini via cron.

---

## Architecture

```
main.py (orchestrator)
  └─> agents/scraper.py        Agent 1: Playwright-based Zillow scraper
  └─> agents/extractor.py      Agent 2: Claude AI data cleaner/structurer
  └─> agents/sheets_writer.py  Agent 3: Google Sheets appender
```

---

## Key Files

| File | Purpose |
|---|---|
| `main.py` | Orchestrator — runs agents in sequence, handles logging and error exits |
| `config.json` | User-editable configuration (location, schedule, sheet ID, etc.) |
| `agents/scraper.py` | Agent 1: Playwright scraper with stealth/human-like behavior |
| `agents/extractor.py` | Agent 2: Batched Claude API calls to clean and structure raw data |
| `agents/sheets_writer.py` | Agent 3: Google Sheets API writer with deduplication |
| `setup.sh` | One-click Mac setup + cron installer |
| `.env` | Secret environment variables (ANTHROPIC_API_KEY) — never committed |
| `google_credentials.json` | Google service account key — never committed |
| `requirements.txt` | Python dependencies |
| `run.log` | Rotating application log (max 5MB, 3 backups) |
| `cron.log` | stdout/stderr from cron-invoked runs |

---

## Agent Details

### Agent 1 — `agents/scraper.py` (ZillowScraper)

- Uses **synchronous Playwright API** (`playwright.sync_api`) — no asyncio, simpler debugging
- Builds Zillow FSBO search URL from `config.json` location (city, state, zip)
- Stealth: injects a JS init script to mask `navigator.webdriver`, spoofs plugins/languages, removes CDP artifacts
- Human-like behavior: random delays between actions, random mouse movements, realistic scrolling
- Rotating user agents via `fake_useragent` with hardcoded fallback pool
- Randomized viewport size (1200–1400 × 800–900)
- Extracts from search result cards: address, price, URL, beds, baths, sqft
- Visits each listing detail page for: phone (via `tel:` links/regex), seller name, description
- Pagination via Next button or numbered page links, up to `max_pages` (from config)
- URL-based deduplication within a single run
- `_is_blocked()` heuristic detects CAPTCHA/bot-detection; logs warning and returns partial results
- All Playwright operations wrapped in try/except — errors per listing are logged and skipped

### Agent 2 — `agents/extractor.py` (DataExtractor)

- Uses `anthropic` Python SDK with model `claude-sonnet-4-6`
- Processes raw listings in batches of `batch_size` (from config, default 5)
- System prompt instructs Claude to return a JSON array with these exact fields:
  `address, city, state, zip_code, price (int), phone_number (XXX-XXX-XXXX), seller_name, bedrooms (int), bathrooms (float), square_footage (int), listing_url, notes`
- Uses `null` for missing values; price normalized to integer (strips $, commas, K/M suffixes)
- Exponential backoff retry (max 3 attempts) on API errors 429/500/502/503/504
- Strips markdown code fences from Claude response before JSON parsing
- Validates each record: must have address AND (price OR phone_number) to be kept
- Deduplicates by normalized address (case-insensitive)
- API key loaded from `ANTHROPIC_API_KEY` environment variable via `python-dotenv`

### Agent 3 — `agents/sheets_writer.py` (SheetsWriter)

- Authenticates via **service account** (path from `config.google_credentials_file`) — works unattended with no token refresh
- Google Sheets API v4 via `google-api-python-client`
- Creates header row on first run (empty sheet)
- Reads ALL existing rows before appending to deduplicate by address
- Prevents intra-batch duplicates by tracking addresses locally during the append loop
- Appends new rows in a single API call
- Default values: Status = `"New"`, Follow Up = `""`, Date Added = today's date (MM/DD/YYYY)
- Returns `{"added": N, "skipped": N, "errors": N}` for summary reporting

### Orchestrator — `main.py`

- Loads `.env` via `python-dotenv` before anything else
- Validates `ANTHROPIC_API_KEY` is set at startup (exits code 1 if missing)
- Loads and logs config from `config.json`
- Runs agents in sequence: scraper → extractor → sheets_writer
- Short-circuits with informational exit (code 0) if agent 1 returns no listings
- `--dry-run` flag skips agent 3 entirely
- Rotating file handler: `run.log`, max 5MB, 3 backups
- Exit codes: 0=success, 1=config/env error, 2=agent1 failure, 3=agent2 failure, 4=agent3 failure

---

## Configuration (`config.json`)

| Key | Purpose |
|---|---|
| `location.city` | City to search |
| `location.state` | Two-letter state code |
| `location.zip` | ZIP code |
| `max_pages` | Max search result pages to scrape per run (default: 10) |
| `headless` | Run browser headlessly (default: true) |
| `min_delay_seconds` | Min human-like delay between Playwright actions |
| `max_delay_seconds` | Max human-like delay |
| `batch_size` | Listings per Claude API call (default: 5) |
| `google_sheet_id` | Google Sheets ID (from URL) |
| `google_credentials_file` | Path to service account JSON key |
| `schedule_hour` | Hour to run cron job (24h, default: 8) |
| `schedule_minute` | Minute to run cron job (default: 0) |

Secrets (`ANTHROPIC_API_KEY`) go in `.env`, never in `config.json`.

---

## Key Design Decisions

**Sync Playwright over async** — The pipeline is linear and single-threaded. Async adds complexity with no throughput benefit here.

**Batched Claude calls** — Sending all listings in one prompt risks token limit errors and high costs. Batching keeps costs predictable and makes partial failures recoverable (failed batches are logged and skipped rather than crashing the run).

**Dual deduplication** — Agent 2 deduplicates by address within a run; Agent 3 deduplicates against the live sheet. Either layer alone has failure modes (stale state, concurrent runs); both together are robust.

**Service account auth** — OAuth requires an interactive browser login that breaks unattended cron execution. Service account JSON key works headlessly with no token refresh required.

**venv + .env isolation** — Keeps system Python clean, makes the project portable, and avoids committing secrets. `python-dotenv` loads `.env` automatically at process start.

**Rotating log file** — 5MB limit with 3 backups prevents `run.log` from growing unbounded over daily runs.

---

## Adding a New Agent

1. Create `agents/your_agent.py` with a class containing a `run(input)` method
2. Add any new config keys to `config.json`
3. Import and wire it into the sequence in `main.py`
4. Document it in this file under Agent Details
