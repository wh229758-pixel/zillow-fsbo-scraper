# Zillow FSBO Scraper — User Guide

---

## 1. What This Does

This tool automatically searches Zillow every day for "For Sale By Owner" (FSBO) listings in your target area and saves them to a Google Sheet for you to review. It uses three automated programs working together to find listings, clean up the data, and record the details — so you never have to manually search Zillow yourself.

---

## 2. What You'll Need

Before you begin, make sure you have the following:

- **Mac Mini** running macOS 11 (Big Sur) or newer
- **Python 3.9 or higher** installed on your Mac ([download here](https://www.python.org/downloads/))
- **Anthropic API key** — you will create this at [console.anthropic.com](https://console.anthropic.com)
- **Google account** — to store your results in Google Sheets
- **Internet connection**

---

## 3. One-Time Setup

You only need to do this once. Follow each step carefully.

### Step 1 — Download the Project

1. Download or clone this project folder to your Mac.
2. Move the folder to your Desktop or Documents folder so it is easy to find.

### Step 2 — Get Your Anthropic API Key

1. Open your web browser and go to [console.anthropic.com](https://console.anthropic.com).
2. Sign up for an account or log in if you already have one.
3. Click **API Keys** in the menu, then click **Create Key**.
4. Give it a name like `zillow-scraper` and click **Create**.
5. **Copy the key immediately** — it starts with `sk-ant-...`. You will not be able to see it again after you close this window.
6. Paste it somewhere safe temporarily (such as a Notes document) until you need it in Step 7.

> **Important:** Keep your API key private. Anyone who has it can use your Anthropic account.

### Step 3 — Set Up Google Sheets Access

This step allows the scraper to write data into your Google Sheet automatically. It involves creating a "service account" — think of it as a robot user that has permission to edit your sheet.

**3a. Create a Google Cloud Project**

1. Go to [console.cloud.google.com](https://console.cloud.google.com) and sign in with your Google account.
2. Click the project dropdown at the top and choose **New Project**.
3. Give your project a name like `zillow-scraper` and click **Create**.

**3b. Enable the Google Sheets API**

1. In the left sidebar, click **APIs & Services** > **Library**.
2. Search for `Google Sheets API`, click on it, then click **Enable**.

**3c. Create a Service Account**

1. Go to **APIs & Services** > **Credentials**.
2. Click **+ Create Credentials** > **Service account**.
3. Name it `zillow-scraper-bot`, click **Create and Continue**.
4. Set the Role to **Basic > Editor**, click **Continue**, then **Done**.

**3d. Download the Credentials File**

1. On the Credentials page, click the service account email you just created.
2. Click the **Keys** tab > **Add Key** > **Create new key** > **JSON** > **Create**.
3. A JSON file downloads automatically.
4. Rename it to exactly `google_credentials.json` (lowercase, no extra words).
5. Move it into the project folder.

**3e. Note Your Service Account Email**

On the Credentials page, copy the service account email address — it looks like `zillow-scraper-bot@your-project.iam.gserviceaccount.com`. You need this in Step 4.

### Step 4 — Create Your Google Sheet and Share It

1. Go to [sheets.google.com](https://sheets.google.com) and create a new blank spreadsheet.
2. Name it `FSBO Listings`.
3. Click **Share**, paste the service account email from Step 3e, set it to **Editor**, and click **Send**.
4. **Get the Sheet ID from the URL.** The URL looks like:

   ```
   https://docs.google.com/spreadsheets/d/1BxiMVs0XRA5nFMdKvBdBZjgmUUqptlbs74OgVE2upms/edit
   ```

   The Sheet ID is the long string between `/d/` and `/edit`. Copy it.

### Step 5 — Edit the Configuration File

1. Open `config.json` in the project folder with TextEdit.
2. Fill in your location and paste the Sheet ID:

   ```json
   {
     "location": {
       "city": "Austin",
       "state": "TX",
       "zip": "78701"
     },
     "google_sheet_id": "paste-your-sheet-id-here"
   }
   ```

3. Save and close.

### Step 6 — Run the Setup Script

1. Open **Terminal** (press Command + Space, type `Terminal`, press Enter).
2. Navigate to the project folder:

   ```
   cd ~/Desktop/zillow-fsbo-scraper
   ```

3. Make the script runnable and run it:

   ```
   chmod +x setup.sh
   ./setup.sh
   ```

4. The script installs everything automatically. This may take a few minutes.

### Step 7 — Add Your Anthropic API Key

1. Open the `.env` file in the project folder with TextEdit.

   > **Note:** The `.env` file is hidden by default. In Finder, press **Command + Shift + .** to show hidden files. Or in TextEdit, go to **File > Open** and press **Command + Shift + .** to reveal them.

2. Replace `your_key_here` with your actual key:

   ```
   ANTHROPIC_API_KEY=sk-ant-your-key-here
   ```

3. Save and close.

That's it — setup is complete. The scraper will now run automatically every day.

---

## 4. Daily Operation

Once setup is complete, you do not need to do anything. The scraper runs automatically in the background at the time configured in `config.json` (default: 8:00 AM daily).

**Viewing logs:** Open the project folder and look for `run.log`. You can open it with TextEdit. Each line shows a timestamped record of what the scraper did.

---

## 5. Viewing Your Results

1. Open your browser and go to [sheets.google.com](https://sheets.google.com).
2. Open the `FSBO Listings` spreadsheet.

Each row represents one FSBO listing. Key columns:

| Column | What It Means |
|---|---|
| **Address** | The property's street address |
| **Price** | The asking price |
| **Phone Number** | Seller's phone number if available |
| **Seller Name** | Name of the seller if listed |
| **Bedrooms / Bathrooms / Sq Footage** | Property details |
| **Listing URL** | Clickable link to the Zillow listing |
| **Status** | Defaults to `New` when added |
| **Follow Up** | Blank column for your own notes |
| **Date Added** | The date the scraper first found this listing |

The scraper never adds duplicate rows. If a listing was already recorded, it is skipped.

---

## 6. Changing the Search Location

1. Open `config.json` with TextEdit.
2. Update the `city`, `state`, and/or `zip` fields to your new target location.
3. Save the file.

The change takes effect automatically on the next run. No need to run setup again.

---

## 7. Changing What Time It Runs

1. Open `config.json` with TextEdit.
2. Update `schedule_hour` and `schedule_minute` (24-hour format):
   - 8:00 AM → `"schedule_hour": 8, "schedule_minute": 0`
   - 6:30 PM → `"schedule_hour": 18, "schedule_minute": 30`
3. Save the file.
4. Re-run setup to apply the new schedule:

   ```
   ./setup.sh
   ```

---

## 8. Running Manually

To run the scraper right now without waiting for the cron schedule:

```bash
source venv/bin/activate
python main.py
```

To test the scrape and AI extraction without writing anything to Google Sheets:

```bash
source venv/bin/activate
python main.py --dry-run
```

---

## 9. Troubleshooting

### No listings appearing / Zillow blocking the scraper

Zillow actively blocks automated access. If listings stop appearing:

- Wait 24 hours — temporary blocks usually lift on their own.
- Check `run.log` for messages mentioning `blocked`, `captcha`, or `403`.
- The scraper uses human-like delays and stealth settings to reduce blocking, but this cannot be fully prevented.

### "Invalid API key" or Anthropic errors

- Open `.env` and confirm your API key is correct with no extra spaces.
- Log into [console.anthropic.com](https://console.anthropic.com) to verify the key is active.
- Check that your Anthropic account has a valid payment method.

### "Google authentication failed" / sheet not updating

- Confirm `google_credentials.json` is in the project folder and named exactly that.
- Confirm you shared the Google Sheet with the service account email (Step 4).
- Confirm `google_sheet_id` in `config.json` matches the ID in your sheet's URL.

### "Python not found" errors

- Open Terminal and type `python3 --version`. If you see an error, install Python from [python.org](https://www.python.org/downloads/).
- After installing Python, run `./setup.sh` again.

---

## 10. How It Works

Three agents run in sequence each day:

1. **Agent 1 — Scraper:** Opens a headless Chromium browser, navigates to Zillow, and searches for FSBO listings in your configured area. It clicks through up to 10 pages of results and visits each listing's detail page to collect raw data including address, price, phone number, and property details.

2. **Agent 2 — AI Extractor:** Sends the raw listing data to Claude (claude-sonnet-4-6) in small batches. Claude cleans and structures the data into consistent records with standardized fields, deduplicates by address, and validates that each record has enough information to be useful.

3. **Agent 3 — Sheets Writer:** Connects to your Google Sheet using a service account, checks which listings are already recorded, and appends only new ones. It adds columns for Status and Follow Up so you can track your outreach.

All three agents are coordinated by `main.py`, which logs everything to `run.log` and prints a summary at the end of each run.

---

## 11. Important Notes

- **Zillow Terms of Service:** Automated scraping of Zillow may violate their [Terms of Service](https://www.zillow.com/z/corp/terms/). Use this tool for personal research only, not commercial purposes.

- **API costs:** Each daily run uses the Anthropic API. Costs are typically very low (a few cents per day), but you are responsible for monitoring your usage at [console.anthropic.com](https://console.anthropic.com).

- **Data accuracy:** The scraper records whatever Zillow displays at the time it runs. Prices and availability can change. Always verify listing details directly on Zillow before acting.
