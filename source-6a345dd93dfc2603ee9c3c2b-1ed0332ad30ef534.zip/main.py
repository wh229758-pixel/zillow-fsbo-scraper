#!/usr/bin/env python3
"""
Zillow FSBO Scraper Orchestrator
---------------------------------
This script orchestrates a 3-agent pipeline for scraping Zillow FSBO listings:
  Agent 1 (agents/scraper.py)   - Scrapes Zillow FSBO listings for a given location
  Agent 2 (agents/extractor.py) - Uses Claude AI to extract and structure listing data
  Agent 3 (agents/sheets_writer.py) - Writes processed listings to a Google Sheet

Usage:
    python main.py [--dry-run]

Config is loaded from config.json. Requires ANTHROPIC_API_KEY env var.
All activity is logged to run.log (rotating) and the console.
"""

import argparse
import json
import logging
import os
import sys
import time
from logging.handlers import RotatingFileHandler
from pathlib import Path

from dotenv import load_dotenv

load_dotenv()


# ---------------------------------------------------------------------------
# Logging setup
# ---------------------------------------------------------------------------

def setup_logging() -> logging.Logger:
    logger = logging.getLogger("zillow_fsbo")
    logger.setLevel(logging.DEBUG)

    formatter = logging.Formatter(
        "%(asctime)s [%(levelname)s] %(name)s: %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )

    # Rotating file handler — max 5 MB, keep 3 backups
    file_handler = RotatingFileHandler(
        "run.log",
        maxBytes=5 * 1024 * 1024,
        backupCount=3,
        encoding="utf-8",
    )
    file_handler.setLevel(logging.DEBUG)
    file_handler.setFormatter(formatter)

    # Console handler
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setLevel(logging.INFO)
    console_handler.setFormatter(formatter)

    logger.addHandler(file_handler)
    logger.addHandler(console_handler)

    return logger


# ---------------------------------------------------------------------------
# Config loader
# ---------------------------------------------------------------------------

def load_config(config_path: str = "config.json") -> dict:
    path = Path(config_path)
    if not path.exists():
        raise FileNotFoundError(f"Config file not found: {config_path}")
    with path.open("r", encoding="utf-8") as fh:
        config = json.load(fh)
    return config


# ---------------------------------------------------------------------------
# Environment validation
# ---------------------------------------------------------------------------

def validate_env(logger: logging.Logger) -> None:
    api_key = os.environ.get("ANTHROPIC_API_KEY", "").strip()
    if not api_key:
        logger.error(
            "ANTHROPIC_API_KEY environment variable is not set or is empty. "
            "Export it before running this script, or add it to the .env file."
        )
        sys.exit(1)
    logger.debug("ANTHROPIC_API_KEY validated (present and non-empty).")


# ---------------------------------------------------------------------------
# Agent runners
# ---------------------------------------------------------------------------

def run_agent1(config: dict, logger: logging.Logger) -> list:
    """Agent 1 — Zillow FSBO scraper. Returns a list of raw listing dicts."""
    logger.info("Agent 1 (scraper) starting...")
    t0 = time.perf_counter()

    try:
        from agents.scraper import ZillowScraper
        agent = ZillowScraper(config=config, logger=logger)
        raw_listings = agent.run()
    except ImportError as exc:
        raise RuntimeError(f"Could not import ZillowScraper: {exc}") from exc

    elapsed = time.perf_counter() - t0
    logger.info(
        "Agent 1 finished in %.2fs — %d raw listings collected.",
        elapsed,
        len(raw_listings),
    )
    return raw_listings


def run_agent2(raw_listings: list, config: dict, logger: logging.Logger) -> list:
    """Agent 2 — AI-powered data extractor. Returns structured listing dicts."""
    logger.info("Agent 2 (AI extractor) starting — %d listings to process...", len(raw_listings))
    t0 = time.perf_counter()

    try:
        from agents.extractor import DataExtractor
        agent = DataExtractor(config=config, logger=logger)
        processed_listings = agent.run(raw_listings)
    except ImportError as exc:
        raise RuntimeError(f"Could not import DataExtractor: {exc}") from exc

    elapsed = time.perf_counter() - t0
    logger.info(
        "Agent 2 finished in %.2fs — %d listings processed.",
        elapsed,
        len(processed_listings),
    )
    return processed_listings


def run_agent3(processed_listings: list, config: dict, logger: logging.Logger) -> dict:
    """Agent 3 — Google Sheets writer. Returns summary dict {added, skipped, errors}."""
    logger.info(
        "Agent 3 (sheets writer) starting — %d listings to write...",
        len(processed_listings),
    )
    t0 = time.perf_counter()

    try:
        from agents.sheets_writer import SheetsWriter
        agent = SheetsWriter(config=config, logger=logger)
        result = agent.run(processed_listings)
    except ImportError as exc:
        raise RuntimeError(f"Could not import SheetsWriter: {exc}") from exc

    elapsed = time.perf_counter() - t0
    logger.info(
        "Agent 3 finished in %.2fs — %d added, %d skipped, %d errors.",
        elapsed,
        result.get("added", 0),
        result.get("skipped", 0),
        result.get("errors", 0),
    )
    return result


# ---------------------------------------------------------------------------
# Summary printer
# ---------------------------------------------------------------------------

def print_summary(
    logger: logging.Logger,
    *,
    scraped: int,
    processed: int,
    sheet_result: dict,
    total_elapsed: float,
    dry_run: bool,
) -> None:
    separator = "=" * 60
    logger.info(separator)
    logger.info("RUN SUMMARY")
    logger.info(separator)
    logger.info("  Listings scraped   : %d", scraped)
    logger.info("  Listings processed : %d", processed)
    if dry_run:
        logger.info("  Rows added (sheet) : SKIPPED (--dry-run mode)")
    else:
        logger.info("  Rows added (sheet) : %d", sheet_result.get("added", 0))
        logger.info("  Rows skipped (dupe): %d", sheet_result.get("skipped", 0))
        if sheet_result.get("errors", 0):
            logger.warning("  Sheet errors       : %d", sheet_result.get("errors", 0))
    logger.info("  Total runtime      : %.2fs", total_elapsed)
    logger.info(separator)


# ---------------------------------------------------------------------------
# CLI argument parsing
# ---------------------------------------------------------------------------

def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Zillow FSBO Scraper — 3-agent orchestrator",
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        default=False,
        help="Scrape and process listings but skip writing to Google Sheets.",
    )
    parser.add_argument(
        "--config",
        default="config.json",
        metavar="PATH",
        help="Path to the JSON config file (default: config.json).",
    )
    return parser.parse_args()


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main() -> None:
    args = parse_args()

    logger = setup_logging()
    logger.info("=" * 60)
    logger.info("Zillow FSBO Scraper starting.")
    logger.info("=" * 60)

    if args.dry_run:
        logger.info("--dry-run flag detected: Google Sheets write step will be skipped.")

    validate_env(logger)

    try:
        config = load_config(args.config)
        loc = config.get("location", {})
        logger.info(
            "Config loaded — location: %s, %s %s | max_pages: %d | batch_size: %d",
            loc.get("city", "?"),
            loc.get("state", "?"),
            loc.get("zip", "?"),
            config.get("max_pages", 10),
            config.get("batch_size", 5),
        )
    except (FileNotFoundError, json.JSONDecodeError) as exc:
        logging.getLogger("zillow_fsbo").error("Failed to load config: %s", exc)
        sys.exit(1)

    total_start = time.perf_counter()
    raw_listings: list = []
    processed_listings: list = []
    sheet_result: dict = {"added": 0, "skipped": 0, "errors": 0}

    # ------------------------------------------------------------------
    # Agent 1 — Scrape
    # ------------------------------------------------------------------
    try:
        raw_listings = run_agent1(config, logger)
    except Exception as exc:
        logger.error("Agent 1 failed: %s", exc, exc_info=True)
        sys.exit(2)

    if not raw_listings:
        logger.warning("Agent 1 returned no listings. Nothing to process — exiting.")
        print_summary(
            logger,
            scraped=0,
            processed=0,
            sheet_result=sheet_result,
            total_elapsed=time.perf_counter() - total_start,
            dry_run=args.dry_run,
        )
        sys.exit(0)

    # ------------------------------------------------------------------
    # Agent 2 — AI extraction
    # ------------------------------------------------------------------
    try:
        processed_listings = run_agent2(raw_listings, config, logger)
    except Exception as exc:
        logger.error("Agent 2 failed: %s", exc, exc_info=True)
        sys.exit(3)

    if not processed_listings:
        logger.warning("Agent 2 returned no processed listings — skipping sheet write.")
        print_summary(
            logger,
            scraped=len(raw_listings),
            processed=0,
            sheet_result=sheet_result,
            total_elapsed=time.perf_counter() - total_start,
            dry_run=args.dry_run,
        )
        sys.exit(0)

    # ------------------------------------------------------------------
    # Agent 3 — Write to Google Sheets (skip in dry-run mode)
    # ------------------------------------------------------------------
    if args.dry_run:
        logger.info("Dry-run mode: skipping Agent 3 (sheets writer).")
    else:
        try:
            sheet_result = run_agent3(processed_listings, config, logger)
        except Exception as exc:
            logger.error("Agent 3 failed: %s", exc, exc_info=True)
            sys.exit(4)

    total_elapsed = time.perf_counter() - total_start

    print_summary(
        logger,
        scraped=len(raw_listings),
        processed=len(processed_listings),
        sheet_result=sheet_result,
        total_elapsed=total_elapsed,
        dry_run=args.dry_run,
    )

    logger.info("Orchestrator finished successfully.")


if __name__ == "__main__":
    main()
